﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Final_National.Models;
using System.Data.Entity.Core.Objects;
using System.Windows.Forms;

namespace Final_National.Controllers
{
    public class ApproverController : Controller
    {


        casestudyEntities db = new casestudyEntities();
        // GET: Approver
        //public ActionResult Index()
        //{
        //    return View();
        //}

        public ActionResult TaskDetails()
        {
            var model = (from u in db.tasks
                         select u).ToList();

            return View(model);
        }
       
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            task task = db.tasks.Find(id);
            if (task == null)
            {
                return HttpNotFound();
            }
            return View(task);
        }





        // POST: tasks/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Task_Id,Title,Description1,From_date,To_date,Category,Store")] task task)
        {
            if (ModelState.IsValid)
            {
                db.Entry(task).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("TaskDetails", "Approver");
            }
            return View(task);
        }


        





        public ActionResult Approve(int id, task app)
        {
            app.Task_Id = id;
            if (ModelState.IsValid)
            {
               
                int? result = 0;
                ObjectParameter objParam = new ObjectParameter("result", typeof(int));
                result = Convert.ToInt32(objParam.Value);
                db.USP_NewTask_Approve(app.Task_Id, objParam);
                if (result == 0)
                {
                    MessageBox.Show("Approved Successfully");
                    return RedirectToAction("ViewRequests", "Approver");
                }
                else
                {
                    MessageBox.Show("Approval failed");
                    return RedirectToAction("ViewRequests");
                }
            }
            //approve app = new approve();
            return View(app);
        }

        public ActionResult Reject(int id, task app)
        {
            app.Task_Id = id;
            if (ModelState.IsValid)
            {

                int? result = 0;
                ObjectParameter objParam = new ObjectParameter("result", typeof(int));
                result = Convert.ToInt32(objParam.Value);
                db.USP_NewTask_Reject(app.Task_Id, objParam);
                if (result == 0)
                {
                    MessageBox.Show("Rejected");
                    return RedirectToAction("ViewRequests", "Approver");
                }
                else
                {
                    MessageBox.Show("Rejection failed");
                    return RedirectToAction("ViewRequests");
                }
            }
            //approve app = new approve();
            return View(app);
        }





        //public ActionResult Reject(int id, task rej)
        //{
        //    rej.Task_Id = id;
        //    if (ModelState.IsValid)
        //    {

        //        int? result = 0;
        //        ObjectParameter objParam = new ObjectParameter("res", typeof(int));
        //        result = Convert.ToInt32(objParam.Value);
        //        db.USP_NewTask_Approve(rej.Task_Id, objParam);
        //        if (result == 0)
        //        {
        //            MessageBox.Show("Rejected");
        //            return RedirectToAction("ViewRequests", "Approver");
        //        }
        //        else
        //        {
        //            MessageBox.Show("Rejection failed");
        //            return RedirectToAction("ViewRequests");
        //        }
        //    }
        //    //approve app = new approve();
        //    return View(rej);
        //}
        public ActionResult ViewRequests()
        {
            
            List<task> viewrequests = db.tasks.Select(r => r).ToList();

            return View(viewrequests);
        }
    }
}