﻿using Final_National.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Objects;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Windows.Forms;

namespace Final_National.Controllers
{
    public class StoreUserController : Controller
    {

        casestudyEntities db = new casestudyEntities();
        // GET: StoreUser
        public ActionResult Index()
        {
            return View();
        }

        //public ActionResult ViewTask(int id, task app)
        //{
        //    app.Task_Id = id;
        //    if (ModelState.IsValid)
        //    {

        //        int? result = 0;
        //        ObjectParameter objParam = new ObjectParameter("result", typeof(int));
        //        result = Convert.ToInt32(objParam.Value);
        //        db.USP_Display_StoreUser(app.Task_Id, objParam);
        //    }
        //    return View(app);
        //}

        public ActionResult ViewTask()
        {
            var model = (from u in db.tasks
                         where u.Status.Equals("Approved")
                         select u).ToList();
            return View(model);
        }
        
        public ActionResult Inprogress(int id, task app)
        {
            app.Task_Id = id;
            if (ModelState.IsValid)
            {

                int? result = 0;
                ObjectParameter objParam = new ObjectParameter("result", typeof(int));
                result = Convert.ToInt32(objParam.Value);
                db.USP_TaskInprogress(app.Task_Id, objParam);
                if (result == 0)
                {
                    MessageBox.Show("Inprogress...");
                    return RedirectToAction("ViewTask", "StoreUser");
                }
                else
                {
                    MessageBox.Show("Approval failed");
                    return RedirectToAction("ViewTask");
                }
            }
            //approve app = new approve();
            return View(app);
        }

        public ActionResult Completed(int id, task app)
        {
            app.Task_Id = id;
            if (ModelState.IsValid)
            {

                int? result = 0;
                ObjectParameter objParam = new ObjectParameter("result", typeof(int));
                result = Convert.ToInt32(objParam.Value);
                db.USP_TaskComplete(app.Task_Id, objParam);
                if (result == 0)
                {
                    MessageBox.Show("Complete...");
                    return RedirectToAction("ViewTask", "StoreUser");
                }
                else
                {
                    MessageBox.Show("Completion failed");
                    return RedirectToAction("ViewTask");
                }
            }
            //approve app = new approve();
            return View(app);
        }
    }
}